function [ output_args ] = SymbolSNR()
%SYMBOLSNR Summary of this function goes here
%   Detailed explanation goes here


end

